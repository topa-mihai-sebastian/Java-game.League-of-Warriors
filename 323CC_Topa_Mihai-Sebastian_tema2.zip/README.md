# TOPA MIHAI-SEBASTIAN 323CC

## Partea 1

- **Timp alocat**: aproximativ 7 zile.
- **Dificultatea temei**: medie, fiind doar mult de scris.
- **Ce am învățat**: cum să lucrez cu mai multe clase implicate în același program.

## Partea 2

- **Timp alocat**: aproximativ 14 zile.
- **Dificultatea temei**: mai ușoară, deoarece aveam fundația deja implementată.
- **Ce am învățat**: multe despre design patterns și cum să fac o interfață grafică minimalistă.

[Proiect pe GitHub](https://github.com/topa-mihai-sebastian/Java-game.League-of-Warriors)